const selectors = {
  cards: '.project-card',
  dialog: '[data-project-modal]',
  close: '[data-project-modal-close]',
  image: '[data-project-modal-image]',
  title: '[data-project-modal-title]',
  subtitle: '[data-project-modal-subtitle]',
  body: '[data-project-modal-body]',
};

const description =
  'This project explores new possibilities in design by rethinking familiar experiences from a fresh perspective. Through thoughtful forms, emerging technologies, and human-centered research, it considers how small changes in everyday life can create more meaningful connections.';
const additionalDescription = 'Detailed project information will be added soon.';
const closeDuration = 650;

export function initProjectsModal() {
  const cards = document.querySelectorAll(selectors.cards);
  const dialog = document.querySelector(selectors.dialog);

  if (!cards.length || !(dialog instanceof HTMLDialogElement)) {
    return;
  }

  const closeButton = dialog.querySelector(selectors.close);
  const image = dialog.querySelector(selectors.image);
  const title = dialog.querySelector(selectors.title);
  const subtitle = dialog.querySelector(selectors.subtitle);
  const body = dialog.querySelector(selectors.body);

  if (
    !(closeButton instanceof HTMLButtonElement) ||
    !(image instanceof HTMLImageElement) ||
    !(title instanceof HTMLElement) ||
    !(subtitle instanceof HTMLElement) ||
    !(body instanceof HTMLElement)
  ) {
    return;
  }

  let activeCard = null;
  let closeTimer = 0;

  const closeModal = () => {
    if (!dialog.open || dialog.classList.contains('is-closing')) {
      return;
    }

    dialog.classList.remove('is-open');
    dialog.classList.add('is-closing');

    const finishClose = () => {
      window.clearTimeout(closeTimer);
      if (dialog.open) {
        dialog.close();
      }
      dialog.classList.remove('is-closing');
      document.body.classList.remove('has-project-modal');
      activeCard?.focus();
    };

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      finishClose();
      return;
    }

    closeTimer = window.setTimeout(finishClose, closeDuration);
  };

  const openModal = (card) => {
    if (dialog.open) {
      return;
    }

    const projectTitle = card.querySelector('.project-card__title')?.textContent?.trim();
    const category = card.querySelector('.project-card__category')?.textContent?.trim();
    const author = card.querySelector('.project-card__name')?.textContent?.trim();
    const thumbnail = card.querySelector('.project-card__thumb img');

    if (!projectTitle || !thumbnail) {
      return;
    }

    activeCard = card;
    image.src = 'images/test-img.png';
    image.alt = projectTitle;
    title.textContent = projectTitle;
    subtitle.textContent = [category, author].filter(Boolean).join(' · ');
    body.replaceChildren();

    [description, additionalDescription].forEach((text) => {
      const paragraph = document.createElement('p');
      paragraph.textContent = text;
      body.append(paragraph);
    });

    dialog.showModal();
    document.body.classList.add('has-project-modal');
    window.requestAnimationFrame(() => {
      dialog.classList.add('is-open');
      closeButton.focus();
    });
  };

  cards.forEach((card) => {
    card.setAttribute('role', 'button');
    card.setAttribute('aria-haspopup', 'dialog');
    const projectTitle = card.querySelector('.project-card__title')?.textContent?.trim();
    if (projectTitle) {
      card.setAttribute('aria-label', `${projectTitle} 프로젝트 상세 보기`);
    }

    card.addEventListener('click', () => openModal(card));
    card.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') {
        return;
      }

      event.preventDefault();
      openModal(card);
    });
  });

  closeButton.addEventListener('click', closeModal);
  dialog.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeModal();
    }
  });
  dialog.addEventListener('cancel', (event) => {
    event.preventDefault();
    closeModal();
  });
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) {
      closeModal();
    }
  });
}
